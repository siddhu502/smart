import React, { useState, useEffect } from 'react';
import { Download, FileText, BookOpen, Star } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { generatePDF } from './PDFGenerator';
import SubjectGrid from './SubjectGrid';

interface FormData {
  type: 'Question' | 'Answer';
  class: string;
  exam: string;
  schoolName: string;
  fullName: string;
  email: string;
  mobile: string;
  selectedSubject: string;
}

interface Subject {
  id: string;
  name: string;
  class_level: string;
  stream: string;
  price: number;
  description?: string;
}

interface StudyMaterial {
  id: string;
  chapter_id: string;
  title: string;
  file_url: string;
  file_type: string;
  file_size?: number;
  mime_type?: string;
}

const UserDashboard: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    type: 'Question',
    class: '',
    exam: '',
    schoolName: '',
    fullName: '',
    email: '',
    mobile: '',
    selectedSubject: ''
  });

  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [availableMaterials, setAvailableMaterials] = useState<StudyMaterial[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedSubjectData, setSelectedSubjectData] = useState<Subject | null>(null);

  const classes = [
    { value: '11', label: 'अकरावी (Class XI)' },
    { value: '12', label: 'बारावी (Class XII)' }
  ];

  const exams = {
    '11': ['Unit Test', 'First Term', 'Second Term', 'Final Exam'],
    '12': ['Unit Test', 'First Term', 'Prelim Exam', 'HSC Board Exam']
  };

  useEffect(() => {
    fetchSubjects();
  }, []);

  useEffect(() => {
    if (selectedSubjectData) {
      fetchStudyMaterials(selectedSubjectData.id);
    }
  }, [selectedSubjectData, formData.type]);

  const fetchSubjects = async () => {
    const { data, error } = await supabase
      .from('subjects')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) {
      console.error('Error fetching subjects:', error);
    } else {
      setSubjects(data || []);
    }
  };

  const fetchStudyMaterials = async (subjectId: string) => {
    setIsLoading(true);
    
    const { data: chapters } = await supabase
      .from('chapters')
      .select('id')
      .eq('subject_id', subjectId);

    if (chapters && chapters.length > 0) {
      const chapterIds = chapters.map(c => c.id);
      
      const { data: materials, error } = await supabase
        .from('study_materials')
        .select('*')
        .in('chapter_id', chapterIds)
        .eq('file_type', formData.type === 'Question' ? 'question_paper' : 'answer_sheet');

      if (error) {
        console.error('Error fetching study materials:', error);
      } else {
        setAvailableMaterials(materials || []);
      }
    } else {
      setAvailableMaterials([]);
    }
    
    setIsLoading(false);
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
      ...(field === 'class' ? { exam: '', selectedSubject: '' } : {}),
      ...(field === 'type' ? { selectedSubject: '' } : {})
    }));
    
    if (field === 'class' || field === 'type') {
      setSelectedSubjectData(null);
      setAvailableMaterials([]);
    }
  };

  const handleSubjectSelect = (subject: Subject) => {
    setSelectedSubjectData(subject);
    setFormData(prev => ({ ...prev, selectedSubject: subject.id }));
  };

  const handleDownload = async (material: StudyMaterial) => {
    if (!formData.fullName || !formData.schoolName) {
      alert('कृपया नाव आणि विद्यालयाचे नाव भरा (Please fill name and school name)');
      return;
    }

    try {
      // Fetch the PDF content
      const response = await fetch(material.file_url);
      const blob = await response.blob();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      
      // Generate filename with college name
      const filename = `${formData.schoolName}_${selectedSubjectData?.name}_${formData.exam}_${material.title}.pdf`;
      link.download = filename;
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      alert('डाउनलोड सुरू झाले! (Download started!)');
    } catch (error) {
      console.error('Download error:', error);
      alert('डाउनलोड करताना त्रुटी झाली (Error during download)');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3">
          <nav className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-3 rounded-lg">
                <BookOpen className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  Smart Creations
                </h1>
                <p className="text-sm text-gray-600">Smart Abhyas Portal</p>
              </div>
            </div>
            <div className="hidden md:flex space-x-6">
              <a href="/" className="text-gray-700 hover:text-purple-600 transition-colors">Home</a>
              <a href="/admin" className="text-gray-700 hover:text-purple-600 transition-colors">Admin</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors">Contact</a>
            </div>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Form Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                प्रश्नपत्रिका / उत्तरपत्रिका डाउनलोड करा
              </h2>
              
              {/* Type Selection */}
              <div className="flex gap-4 mb-6">
                <label className={`flex-1 cursor-pointer ${formData.type === 'Question' ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white' : 'bg-gray-100 text-gray-700'} p-3 rounded-lg text-center font-semibold transition-all`}>
                  <input
                    type="radio"
                    name="type"
                    value="Question"
                    className="hidden"
                    checked={formData.type === 'Question'}
                    onChange={() => handleInputChange('type', 'Question')}
                  />
                  प्रश्नपत्रिका
                </label>
                <label className={`flex-1 cursor-pointer ${formData.type === 'Answer' ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white' : 'bg-gray-100 text-gray-700'} p-3 rounded-lg text-center font-semibold transition-all`}>
                  <input
                    type="radio"
                    name="type"
                    value="Answer"
                    className="hidden"
                    checked={formData.type === 'Answer'}
                    onChange={() => handleInputChange('type', 'Answer')}
                  />
                  उत्तरपत्रिका
                </label>
              </div>
            </div>

            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">इयत्ता (Class)</label>
                  <select
                    value={formData.class}
                    onChange={(e) => handleInputChange('class', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="">इयत्ता निवडा</option>
                    {classes.map(cls => (
                      <option key={cls.value} value={cls.value}>{cls.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">परीक्षा निवडा (Select Exam)</label>
                  <select
                    value={formData.exam}
                    onChange={(e) => handleInputChange('exam', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    disabled={!formData.class}
                  >
                    <option value="">परीक्षा निवडा</option>
                    {formData.class && exams[formData.class as keyof typeof exams]?.map(exam => (
                      <option key={exam} value={exam}>{exam}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Subject Selection */}
              <SubjectGrid
                subjects={subjects}
                selectedClass={formData.class}
                selectedExam={formData.exam}
                onSubjectSelect={handleSubjectSelect}
              />

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">विद्यालय / कॉलेज नाव *</label>
                <input
                  type="text"
                  value={formData.schoolName}
                  onChange={(e) => handleInputChange('schoolName', e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Your school/college name"
                  required
                />
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">वैयक्तिक माहिती (Personal Information)</h3>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">नाव (Name) *</label>
                    <input
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => handleInputChange('fullName', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="Your full name"
                      required
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">ई-मेल (Email)</label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="your.email@example.com"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">मोबाईल (Mobile)</label>
                      <input
                        type="tel"
                        value={formData.mobile}
                        onChange={(e) => handleInputChange('mobile', e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="9876543210"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Available Materials */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">
              उपलब्ध अभ्यासक्रम (Available Materials)
            </h3>
            
            {!selectedSubjectData ? (
              <div className="text-center py-8">
                <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">कृपया विषय निवडा (Please select a subject)</p>
              </div>
            ) : isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto"></div>
                <p className="text-gray-500 mt-2">लोड होत आहे... (Loading...)</p>
              </div>
            ) : availableMaterials.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">
                  या विषयासाठी {formData.type === 'Question' ? 'प्रश्नपत्रिका' : 'उत्तरपत्रिका'} उपलब्ध नाही
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {availableMaterials.map((material) => (
                  <div key={material.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-medium text-gray-800">{material.title}</h4>
                        <p className="text-sm text-gray-600">
                          {selectedSubjectData.name} - {formData.exam}
                        </p>
                        <div className="flex items-center mt-1">
                          <Star className="w-4 h-4 text-yellow-500 mr-1" />
                          <span className="text-xs text-gray-500">
                            {material.file_size ? Math.round(material.file_size / 1024) + ' KB' : 'PDF'}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDownload(material)}
                        className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-300 flex items-center space-x-2"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default UserDashboard;