import React, { useState, useEffect } from 'react';
import { Upload, FileText, Plus, Trash2, Edit, Save, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Subject {
  id: string;
  name: string;
  class_level: string;
  stream: string;
  price: number;
  description?: string;
}

interface Chapter {
  id: string;
  subject_id: string;
  name: string;
  chapter_number: number;
  description?: string;
}

interface StudyMaterial {
  id: string;
  chapter_id: string;
  title: string;
  file_url: string;
  file_type: string;
  file_size?: number;
  mime_type?: string;
}

const AdminPanel: React.FC = () => {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [studyMaterials, setStudyMaterials] = useState<StudyMaterial[]>([]);
  const [activeTab, setActiveTab] = useState<'subjects' | 'chapters' | 'materials'>('subjects');
  const [isLoading, setIsLoading] = useState(false);
  const [editingItem, setEditingItem] = useState<string | null>(null);

  // Form states
  const [newSubject, setNewSubject] = useState({
    name: '',
    class_level: '',
    stream: '',
    price: 0,
    description: ''
  });

  const [newChapter, setNewChapter] = useState({
    subject_id: '',
    name: '',
    chapter_number: 1,
    description: ''
  });

  const [newMaterial, setNewMaterial] = useState({
    chapter_id: '',
    title: '',
    file_type: 'question_paper',
    file: null as File | null
  });

  useEffect(() => {
    fetchSubjects();
    fetchChapters();
    fetchStudyMaterials();
  }, []);

  const fetchSubjects = async () => {
    const { data, error } = await supabase
      .from('subjects')
      .select('*')
      .order('class_level', { ascending: true });
    
    if (error) {
      console.error('Error fetching subjects:', error);
    } else {
      setSubjects(data || []);
    }
  };

  const fetchChapters = async () => {
    const { data, error } = await supabase
      .from('chapters')
      .select('*')
      .order('chapter_number', { ascending: true });
    
    if (error) {
      console.error('Error fetching chapters:', error);
    } else {
      setChapters(data || []);
    }
  };

  const fetchStudyMaterials = async () => {
    const { data, error } = await supabase
      .from('study_materials')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching study materials:', error);
    } else {
      setStudyMaterials(data || []);
    }
  };

  const handleAddSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const { data, error } = await supabase
      .from('subjects')
      .insert([newSubject])
      .select();

    if (error) {
      console.error('Error adding subject:', error);
      alert('Error adding subject');
    } else {
      setSubjects([...subjects, data[0]]);
      setNewSubject({ name: '', class_level: '', stream: '', price: 0, description: '' });
      alert('Subject added successfully!');
    }
    setIsLoading(false);
  };

  const handleAddChapter = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const { data, error } = await supabase
      .from('chapters')
      .insert([newChapter])
      .select();

    if (error) {
      console.error('Error adding chapter:', error);
      alert('Error adding chapter');
    } else {
      setChapters([...chapters, data[0]]);
      setNewChapter({ subject_id: '', name: '', chapter_number: 1, description: '' });
      alert('Chapter added successfully!');
    }
    setIsLoading(false);
  };

  const handleFileUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMaterial.file) {
      alert('Please select a file');
      return;
    }

    setIsLoading(true);

    try {
      // Upload file to Supabase Storage
      const fileExt = newMaterial.file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `study-materials/${fileName}`;

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('study-materials')
        .upload(filePath, newMaterial.file);

      if (uploadError) {
        throw uploadError;
      }

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('study-materials')
        .getPublicUrl(filePath);

      // Save material record
      const materialData = {
        chapter_id: newMaterial.chapter_id,
        title: newMaterial.title,
        file_url: publicUrl,
        file_type: newMaterial.file_type,
        file_size: newMaterial.file.size,
        mime_type: newMaterial.file.type
      };

      const { data, error } = await supabase
        .from('study_materials')
        .insert([materialData])
        .select();

      if (error) {
        throw error;
      }

      setStudyMaterials([data[0], ...studyMaterials]);
      setNewMaterial({ chapter_id: '', title: '', file_type: 'question_paper', file: null });
      alert('Study material uploaded successfully!');
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Error uploading file');
    }
    setIsLoading(false);
  };

  const handleDeleteSubject = async (id: string) => {
    if (!confirm('Are you sure you want to delete this subject?')) return;

    const { error } = await supabase
      .from('subjects')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Error deleting subject:', error);
      alert('Error deleting subject');
    } else {
      setSubjects(subjects.filter(s => s.id !== id));
      alert('Subject deleted successfully!');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-6">Admin Panel</h1>
          
          {/* Tab Navigation */}
          <div className="flex space-x-4 mb-6 border-b">
            <button
              onClick={() => setActiveTab('subjects')}
              className={`pb-2 px-4 ${activeTab === 'subjects' ? 'border-b-2 border-purple-600 text-purple-600' : 'text-gray-600'}`}
            >
              Subjects
            </button>
            <button
              onClick={() => setActiveTab('chapters')}
              className={`pb-2 px-4 ${activeTab === 'chapters' ? 'border-b-2 border-purple-600 text-purple-600' : 'text-gray-600'}`}
            >
              Chapters
            </button>
            <button
              onClick={() => setActiveTab('materials')}
              className={`pb-2 px-4 ${activeTab === 'materials' ? 'border-b-2 border-purple-600 text-purple-600' : 'text-gray-600'}`}
            >
              Study Materials
            </button>
          </div>

          {/* Subjects Tab */}
          {activeTab === 'subjects' && (
            <div>
              <h2 className="text-xl font-semibold mb-4">Manage Subjects</h2>
              
              {/* Add Subject Form */}
              <form onSubmit={handleAddSubject} className="bg-gray-50 p-4 rounded-lg mb-6">
                <h3 className="text-lg font-medium mb-3">Add New Subject</h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <input
                    type="text"
                    placeholder="Subject Name"
                    value={newSubject.name}
                    onChange={(e) => setNewSubject({...newSubject, name: e.target.value})}
                    className="p-2 border rounded"
                    required
                  />
                  <select
                    value={newSubject.class_level}
                    onChange={(e) => setNewSubject({...newSubject, class_level: e.target.value})}
                    className="p-2 border rounded"
                    required
                  >
                    <option value="">Select Class</option>
                    <option value="11">Class 11</option>
                    <option value="12">Class 12</option>
                  </select>
                  <select
                    value={newSubject.stream}
                    onChange={(e) => setNewSubject({...newSubject, stream: e.target.value})}
                    className="p-2 border rounded"
                    required
                  >
                    <option value="">Select Stream</option>
                    <option value="Science">Science</option>
                    <option value="Commerce">Commerce</option>
                    <option value="Arts">Arts</option>
                  </select>
                  <input
                    type="number"
                    placeholder="Price"
                    value={newSubject.price}
                    onChange={(e) => setNewSubject({...newSubject, price: Number(e.target.value)})}
                    className="p-2 border rounded"
                    min="0"
                  />
                  <input
                    type="text"
                    placeholder="Description"
                    value={newSubject.description}
                    onChange={(e) => setNewSubject({...newSubject, description: e.target.value})}
                    className="p-2 border rounded"
                  />
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="bg-purple-600 text-white p-2 rounded hover:bg-purple-700 disabled:opacity-50"
                  >
                    <Plus className="w-4 h-4 inline mr-1" />
                    Add Subject
                  </button>
                </div>
              </form>

              {/* Subjects List */}
              <div className="grid gap-4">
                {subjects.map((subject) => (
                  <div key={subject.id} className="bg-white border rounded-lg p-4 flex justify-between items-center">
                    <div>
                      <h4 className="font-medium">{subject.name}</h4>
                      <p className="text-sm text-gray-600">
                        Class {subject.class_level} - {subject.stream} - ₹{subject.price}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setEditingItem(subject.id)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteSubject(subject.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Chapters Tab */}
          {activeTab === 'chapters' && (
            <div>
              <h2 className="text-xl font-semibold mb-4">Manage Chapters</h2>
              
              {/* Add Chapter Form */}
              <form onSubmit={handleAddChapter} className="bg-gray-50 p-4 rounded-lg mb-6">
                <h3 className="text-lg font-medium mb-3">Add New Chapter</h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <select
                    value={newChapter.subject_id}
                    onChange={(e) => setNewChapter({...newChapter, subject_id: e.target.value})}
                    className="p-2 border rounded"
                    required
                  >
                    <option value="">Select Subject</option>
                    {subjects.map((subject) => (
                      <option key={subject.id} value={subject.id}>
                        {subject.name} (Class {subject.class_level})
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    placeholder="Chapter Name"
                    value={newChapter.name}
                    onChange={(e) => setNewChapter({...newChapter, name: e.target.value})}
                    className="p-2 border rounded"
                    required
                  />
                  <input
                    type="number"
                    placeholder="Chapter Number"
                    value={newChapter.chapter_number}
                    onChange={(e) => setNewChapter({...newChapter, chapter_number: Number(e.target.value)})}
                    className="p-2 border rounded"
                    min="1"
                    required
                  />
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="bg-purple-600 text-white p-2 rounded hover:bg-purple-700 disabled:opacity-50"
                  >
                    <Plus className="w-4 h-4 inline mr-1" />
                    Add Chapter
                  </button>
                </div>
              </form>

              {/* Chapters List */}
              <div className="grid gap-4">
                {chapters.map((chapter) => {
                  const subject = subjects.find(s => s.id === chapter.subject_id);
                  return (
                    <div key={chapter.id} className="bg-white border rounded-lg p-4">
                      <h4 className="font-medium">Chapter {chapter.chapter_number}: {chapter.name}</h4>
                      <p className="text-sm text-gray-600">
                        Subject: {subject?.name} (Class {subject?.class_level})
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Study Materials Tab */}
          {activeTab === 'materials' && (
            <div>
              <h2 className="text-xl font-semibold mb-4">Manage Study Materials</h2>
              
              {/* Upload Material Form */}
              <form onSubmit={handleFileUpload} className="bg-gray-50 p-4 rounded-lg mb-6">
                <h3 className="text-lg font-medium mb-3">Upload Study Material</h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <select
                    value={newMaterial.chapter_id}
                    onChange={(e) => setNewMaterial({...newMaterial, chapter_id: e.target.value})}
                    className="p-2 border rounded"
                    required
                  >
                    <option value="">Select Chapter</option>
                    {chapters.map((chapter) => {
                      const subject = subjects.find(s => s.id === chapter.subject_id);
                      return (
                        <option key={chapter.id} value={chapter.id}>
                          {subject?.name} - Ch.{chapter.chapter_number}: {chapter.name}
                        </option>
                      );
                    })}
                  </select>
                  <input
                    type="text"
                    placeholder="Material Title"
                    value={newMaterial.title}
                    onChange={(e) => setNewMaterial({...newMaterial, title: e.target.value})}
                    className="p-2 border rounded"
                    required
                  />
                  <select
                    value={newMaterial.file_type}
                    onChange={(e) => setNewMaterial({...newMaterial, file_type: e.target.value})}
                    className="p-2 border rounded"
                    required
                  >
                    <option value="question_paper">Question Paper</option>
                    <option value="answer_sheet">Answer Sheet</option>
                    <option value="notes">Notes</option>
                    <option value="practice_paper">Practice Paper</option>
                    <option value="video">Video</option>
                  </select>
                  <input
                    type="file"
                    onChange={(e) => setNewMaterial({...newMaterial, file: e.target.files?.[0] || null})}
                    className="p-2 border rounded"
                    accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.mp4"
                    required
                  />
                </div>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="mt-4 bg-purple-600 text-white p-2 rounded hover:bg-purple-700 disabled:opacity-50"
                >
                  <Upload className="w-4 h-4 inline mr-1" />
                  Upload Material
                </button>
              </form>

              {/* Materials List */}
              <div className="grid gap-4">
                {studyMaterials.map((material) => {
                  const chapter = chapters.find(c => c.id === material.chapter_id);
                  const subject = subjects.find(s => s.id === chapter?.subject_id);
                  return (
                    <div key={material.id} className="bg-white border rounded-lg p-4">
                      <h4 className="font-medium">{material.title}</h4>
                      <p className="text-sm text-gray-600">
                        {subject?.name} - Chapter {chapter?.chapter_number}: {chapter?.name}
                      </p>
                      <p className="text-xs text-gray-500">
                        Type: {material.file_type} | Size: {material.file_size ? Math.round(material.file_size / 1024) + ' KB' : 'Unknown'}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;