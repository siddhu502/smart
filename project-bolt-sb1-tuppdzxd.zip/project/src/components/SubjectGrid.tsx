import React from 'react';
import { BookOpen, Calculator, Globe, Atom, Dna, Users, Brain, TrendingUp, Handshake, Building, LampDesk as Desktop, Heart, Scaling as Seedling } from 'lucide-react';

interface Subject {
  id: string;
  name: string;
  class_level: string;
  stream: string;
  price: number;
  description?: string;
}

interface SubjectGridProps {
  subjects: Subject[];
  selectedClass: string;
  selectedExam: string;
  onSubjectSelect: (subject: Subject) => void;
}

const getSubjectIcon = (subjectName: string) => {
  const iconMap: { [key: string]: any } = {
    'Marathi': Globe,
    'Hindi': Globe,
    'English': Globe,
    'History': BookOpen,
    'Geography': Globe,
    'Political Science': Users,
    'Sociology': Users,
    'Education': BookOpen,
    'Psychology': Brain,
    'Economics': TrendingUp,
    'Cooperation': Handshake,
    'Secretarial Procedure': BookOpen,
    'Commerce & Management': Building,
    'Book Keeping & Accountancy': Calculator,
    'Physics': Atom,
    'Chemistry': Atom,
    'Biology': Dna,
    'Mathematics': Calculator,
    'Information Technology': Desktop,
    'Health & Physical Education': Heart,
    'Environmental Science': Seedling
  };
  
  return iconMap[subjectName] || BookOpen;
};

const SubjectGrid: React.FC<SubjectGridProps> = ({ 
  subjects, 
  selectedClass, 
  selectedExam, 
  onSubjectSelect 
}) => {
  if (!selectedClass || !selectedExam) {
    return null;
  }

  const filteredSubjects = subjects.filter(subject => 
    subject.class_level === selectedClass
  );

  if (filteredSubjects.length === 0) {
    return (
      <div className="mt-6 p-4 bg-gray-50 rounded-lg text-center">
        <p className="text-gray-600">या इयत्तेसाठी विषय उपलब्ध नाहीत</p>
      </div>
    );
  }

  return (
    <div className="mt-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">
        विषय निवडा (Select Subject)
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {filteredSubjects.map((subject) => {
          const IconComponent = getSubjectIcon(subject.name);
          return (
            <button
              key={subject.id}
              onClick={() => onSubjectSelect(subject)}
              className="bg-white hover:bg-gradient-to-br hover:from-purple-50 hover:to-pink-50 p-4 rounded-lg text-center transition-all duration-300 hover:shadow-md border hover:border-purple-200 group"
            >
              <IconComponent className="w-6 h-6 mx-auto mb-2 text-purple-600 group-hover:text-purple-700" />
              <span className="text-sm font-medium text-gray-700 group-hover:text-gray-800">
                {subject.name}
              </span>
              {subject.price > 0 && (
                <div className="text-xs text-green-600 mt-1">
                  ₹{subject.price}
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default SubjectGrid;