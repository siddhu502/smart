import jsPDF from 'jspdf';

interface PDFGeneratorProps {
  content: string;
  collegeName: string;
  studentName: string;
  className: string;
  examType: string;
  subjectName: string;
  language: 'hindi' | 'marathi' | 'english';
}

export const generatePDF = ({
  content,
  collegeName,
  studentName,
  className,
  examType,
  subjectName,
  language
}: PDFGeneratorProps) => {
  const pdf = new jsPDF();
  
  // Set font for different languages
  pdf.setFont('helvetica', 'normal');
  
  // Add college name at top with Kokila font style (size 24)
  pdf.setFontSize(24);
  pdf.setFont('helvetica', 'bold');
  
  // Center the college name
  const pageWidth = pdf.internal.pageSize.getWidth();
  const collegeNameWidth = pdf.getTextWidth(collegeName);
  const collegeNameX = (pageWidth - collegeNameWidth) / 2;
  
  pdf.text(collegeName, collegeNameX, 30);
  
  // Add diagonal watermark
  pdf.setFontSize(50);
  pdf.setTextColor(200, 200, 200);
  pdf.text(collegeName, 50, 150, { angle: 45 });
  
  // Reset color for content
  pdf.setTextColor(0, 0, 0);
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  
  // Add exam details
  pdf.text(`Student: ${studentName}`, 20, 50);
  pdf.text(`Class: ${className}`, 20, 60);
  pdf.text(`Exam: ${examType}`, 20, 70);
  pdf.text(`Subject: ${subjectName}`, 20, 80);
  pdf.text(`Date: ${new Date().toLocaleDateString()}`, 20, 90);
  
  // Add content
  const lines = pdf.splitTextToSize(content, 170);
  pdf.text(lines, 20, 110);
  
  // Generate filename
  const filename = `${subjectName}_${examType}_${className}_${studentName}.pdf`;
  
  // Download the PDF
  pdf.save(filename);
};